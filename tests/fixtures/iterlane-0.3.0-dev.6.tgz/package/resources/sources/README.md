# 来源与适配记录

| 查什么 | 去哪里 |
| --- | --- |
| 上游候选、采用范围和核对状态 | [catalog.yaml](catalog.yaml) |
| 每项 Skill 的职责与版本 | [能力索引](../skills/README.md) |
| 固定文件、摘要、改造、依赖与完整许可 | 各 Skill 的 `NOTICE.md` |
| 方法怎样适配本框架 | [能力适配设计](../docs/design/capability-reuse.md) |

全部是选定方法的适配，不表示整个上游运行时已集成。部署回退和线上调查前置来自本框架规则，不冒称上游部署能力。

第1步另采用锁定版本的yaml、Ajv及4项传递运行依赖，esbuild仅作构建。版本、SRI和许可证见`package-lock.json`、catalog的`step1_adoption`及构建包的`dependency-manifest.json`/`THIRD_PARTY_NOTICES.md`；本轮以`--ignore-scripts`安装，实际执行了已核对的Windows esbuild二进制。

引入前记录：

- 仓库、具体文件和固定版本。
- 许可证、署名与再分发要求。
- 直接复用、适配或自行设计的范围与理由。
- 输入输出、依赖、脚本、副作用和写入位置。
- 确认或状态机制的改造、验证结果与未解决问题。

OpenSpec 本地参考提交只表示阅读快照，不表示采用。未知许可或版本留空，不推测填写；上游变化先显式评估和验证，不自动覆盖。
