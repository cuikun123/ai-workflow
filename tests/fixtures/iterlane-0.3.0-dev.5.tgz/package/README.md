# Iterlane 内部资源包

在已存在的新项目目录安装：node bin/iterlane.mjs init --project <dir> --preview --json，核对后执行同样命令并去掉--preview。

check [--package <dir> | --project <dir>]检查资源；validate --state <file>只校验YAML/state结构。项目内入口为node .ai-workflow/bin/iterlane.mjs check --json，可脱离源码、node_modules和网络运行。

status --json只读诊断书签、文档和记录；check --documents --json补文档检查。获准的主流程使用transition --input <json> --json做受校验的语义转换，记录协议见项目Skills中的workflow-guide/references/state-runtime.md。未完成状态写入使用transition --resume或--undo，加--expected-revision <n>；undo以新revision表示恢复位置。工具校验本地声明及内容版本，不认证人类验收、检查执行或审查身份。

doctor --project <dir> --json聚合本地资源、版本、状态、日志和锁的问题；默认不探测网络或读取全局凭据，显式client-evidence是未认证观察。recover --repair --package <同一固定包> --preview，或--resume/--undo --operation-id <uuid>按日志类别补匹配来源或--expected-revision；核对预览和原授权后才执行。recover --refresh还需准确revision与稳定request-id；恢复不重试业务动作。doctor退出0表示诊断运行完成，local_valid及findings表达实际检查结果。

同版本缺失资源使用init --project <dir> --repair；未完成初始化可显式--resume或--undo。有效日志形成前中断会停止并保留现场；用户改变的资源不自动覆盖。

初始化及状态写入在.gitattributes维护精确路径的管理区块，保留框架资源、入口、state和摘要依据的原字节；其他代码及外来Skills沿原Git文本规则处理。区块外规则保持，特殊filter/更高优先级属性仍须单独核对。旧开发版本不会自动迁移。

安装不代表客户端接入或用户验收。升级、跨项目调度和业务Git/部署执行未实现；此private开发包不可发布。

Copyright (c) 2026 TY. MIT见LICENSE；第三方许可见THIRD_PARTY_NOTICES.md及resources/skills/*/NOTICE.md。
